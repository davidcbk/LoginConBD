Visit the below endpoints<br/>

Login:<br/>
http://localhost:8082/proyecto/login.php<br/><br/>

Registration:<br/>
http://localhost:8082/proyecto/register.php<br/><br/>
